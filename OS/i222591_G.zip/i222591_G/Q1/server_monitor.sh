#!/bin/bash


LOG_FILE="/var/log/serverlog_monitor.log"

log_message() {
    echo "$(date): $1" >> $LOG_FILE  
    if [[ $? -ne 0 ]]; then
        echo "Failed to write to log file: $LOG_FILE" 
    fi
    echo "$(date): $1"  
}

log_message "Server monitor script started."

# Thresholds for monitoring
DISK_THRESHOLD=50  
CPU_THRESHOLD=50    
MEM_THRESHOLD=30    

# Disk Usage Monitoring
disk_usage=$(df / | grep / | awk '{print $5}' | sed 's/%//g')
log_message "Disk usage: $disk_usage%"
if [ "$disk_usage" -gt "$DISK_THRESHOLD" ]; then
    log_message "Disk usage is above ${DISK_THRESHOLD}%: ${disk_usage}%"
fi

# CPU Usage Monitoring
cpu_usage=$(top -bn1 | grep "Cpu(s)" |  awk '{print 100 - $1}')
log_message "CPU usage: $cpu_usage%"
if (( $(echo "$cpu_usage > $CPU_THRESHOLD" | bc -l) )); then
    log_message "CPU usage is above ${CPU_THRESHOLD}%: ${cpu_usage}%"
fi

# Memory Usage Monitoring
mem_free=$(free | grep Mem | awk '{print $4/$2 * 100.0}')
log_message "Memory available: $mem_free%"
if (( $(echo "$mem_free < $MEM_THRESHOLD" | bc -l) )); then
    log_message "Memory available is below ${MEM_THRESHOLD}%: ${mem_free}%"
fi

# Log Rotation
logrotate_conf="/etc/logrotate.d/server_monitor"
if [ -f "$logrotate_conf" ]; then
    sudo logrotate -f "$logrotate_conf"
else
    log_message "Logrotate configuration file not found: $logrotate_conf"
fi
