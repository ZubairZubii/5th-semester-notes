#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to print a left-aligned triangle pattern
void print_left_aligned(int n) {
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= i; j++) {
            printf("*");
        }
        printf("\n");
    }
}

// Function to print an inverted full triangle with increasing double spaces between the two triangles
void print_inverted_full(int n) {
    for (int i = n; i >= 1; i--) {
        for (int j = 1; j <= i; j++) {
            printf("*");
        }

        for (int space = 1; space <= (n - i) * 2 + 1; space++) {  // Adjust this part
            printf(" ");
        }

        for (int j = 1; j <= i; j++) {
            printf("*");
        }

        printf("\n");
    }
}


// Function to print a right-aligned triangle pattern
void print_right_aligned(int n) {
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n - i; j++) {
            printf(" ");
        }
        for (int k = 1; k <= i; k++) {
            printf("*");
        }
        printf("\n");
    }
}

int main() {
    char pattern_option[20];
    int n;

    printf("Enter pattern_option (left, inverted_full, or right): ");
    scanf("%s", pattern_option);

    printf("Enter the number of rows: ");
    scanf("%d", &n);

    if (n <= 0) {
        printf("Error: 'number' must be a positive integer.\n");
        return 1;
    }

    if (strcmp(pattern_option, "left") == 0) {
        print_left_aligned(n);
    } else if (strcmp(pattern_option, "inverted_full") == 0) {
        print_inverted_full(n);
    } else if (strcmp(pattern_option, "right") == 0) {
        print_right_aligned(n);
    } else {
        printf("Error: Invalid pattern_option. Valid options are 'left', 'inverted_full', or 'right'.\n");
        return 1;
    }

    return 0;
}
