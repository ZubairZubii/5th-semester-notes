
#!/bin/bash

# OS Assignment 1 Script
# Filename: OS_Assignment_1.sh

# Initial display of name and roll number
echo "21—2591-ZUBAIR"

# Function to create a new user
create_user() {
    read -p "Enter user: " username
    read -s -p "Enter password: " password
    echo

    # Check if the user already exists
    if id "$username" &>/dev/null; then
        echo "User '$username' already exists."
    else
        # Create the user with plain-text password
        sudo useradd -m -p "$password" "$username"
        sudo usermod -aG sudo "$username"
        echo "User $username is created, and administrator privileges are assigned."
    fi
}


# Function to list installed applications
list_installed_apps() {
    echo "Installed applications:"
    dpkg --get-selections | grep -v deinstall
}

# Function to install an application
install_application() {
    read -p "Enter application name to install (e.g., dropbox): " app_name
    sudo apt update
    sudo apt install -y $app_name
    echo "$app_name has been installed."
}

# Function to configure network settings
configure_network() {
    # Create a virtual interface wlp4s0:0 and configure it with the task's IP settings
    sudo ifconfig wlp4s0:0 10.0.0.1 netmask 255.255.255.0 up
    
    # Add the gateway
    sudo route add default gw 10.0.0.254

    # Set the DNS server
    echo "nameserver 8.8.8.8" | sudo tee /etc/resolv.conf > /dev/null

    # Confirmation message
    echo "Network configuration is set: IP - 10.0.0.1, Gateway - 10.0.0.254, DNS - 8.8.8.8"
}



# Function to display help information
display_help() {
    echo "Available switches and their functionalities:"
    echo "-uc    : Create a new user with admin privileges."
    echo "-ld    : List all installed applications."
    echo "-ins   : Install an application."
    echo "-ipcon : Configure the IP address and network settings."
    echo "-help  : Display this help information."
}

# Check for switches
case "$1" in
    -uc)
        create_user
        ;;
    -ld)
        list_installed_apps
        ;;
    -ins)
        install_application
        ;;
    -ipcon)
        configure_network
        ;;
    -help)
        display_help
        ;;
    *)
        echo "Invalid option. Use -help for available commands."
        ;;
esac
