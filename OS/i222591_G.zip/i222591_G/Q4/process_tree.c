#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

void createProcess(char *name) {
    printf("Process: %s, PID: %d, Parent PID: %d\n", name, getpid(), getppid());
}

int main() {
    printf("Root Process: m, PID: %d\n", getpid());

    // First fork: m creates C1
    pid_t pidC1 = fork();
    if (pidC1 == 0) {
        // Inside C1
        createProcess("C1");

        // Second fork: C1 creates C3
        pid_t pidC3 = fork();
        if (pidC3 == 0) {
            createProcess("C3");

            // Fourth fork: C3 creates C9
            pid_t pidC9 = fork();
            if (pidC9 == 0) {
                createProcess("C9");

                // Fifth fork: C9 creates 19
                pid_t pid19 = fork();
                if (pid19 == 0) {
                    createProcess("19"); // Inside 19
                } else {
                    wait(NULL); // C9 waits for 19 to finish
                    printf("Parent Process ID: %d, waiting for child 19 to finish\n", getpid());
                }

                exit(0); // C9 terminates
            } else {
                wait(NULL); // C3 waits for C9 to finish
                printf("Parent Process ID: %d, waiting for child C9 to finish\n", getpid());

                // Fifth fork: C3 creates 18
                pid_t pid18 = fork();
                if (pid18 == 0) {
                    createProcess("18"); // Inside 18
                } else {
                    wait(NULL); // C3 waits for 18 to finish
                    printf("Parent Process ID: %d, waiting for child 18 to finish\n", getpid());
                }

                exit(0); // C3 terminates
            }

        } else {
            wait(NULL); // C1 waits for C3 to finish
            printf("Parent Process ID: %d, waiting for child C3 to finish\n", getpid());

            // Third fork: C1 creates C5
            pid_t pidC5 = fork();
            if (pidC5 == 0) {
                createProcess("C5");

                // Fourth fork: C5 creates C8
                pid_t pidC8 = fork();
                if (pidC8 == 0) {
                    createProcess("C8");

                    // Fifth fork: C8 creates 17
                    pid_t pid17 = fork();
                    if (pid17 == 0) {
                        createProcess("17"); // Inside 17
                    } else {
                        wait(NULL); // C8 waits for 17 to finish
                        printf("Parent Process ID: %d, waiting for child 17 to finish\n", getpid());
                    }

                    exit(0); // C8 terminates
                } else {
                    wait(NULL); // C5 waits for C8 to finish
                    printf("Parent Process ID: %d, waiting for child C8 to finish\n", getpid());

                    // Fifth fork: C5 creates 16
                    pid_t pid16 = fork();
                    if (pid16 == 0) {
                        createProcess("16"); // Inside 16
                    } else {
                        wait(NULL); // C5 waits for 16 to finish
                        printf("Parent Process ID: %d, waiting for child 16 to finish\n", getpid());
                    }

                    exit(0); // C5 terminates
                }

            } else {
                wait(NULL); // C1 waits for C5 to finish
                printf("Parent Process ID: %d, waiting for child C5 to finish\n", getpid());

                // Fifth fork: C1 creates 15
                pid_t pid15 = fork();
                if (pid15 == 0) {
                    createProcess("15"); // Inside 15
                } else {
                    wait(NULL); // C1 waits for 15 to finish
                    printf("Parent Process ID: %d, waiting for child 15 to finish\n", getpid());
                }

                exit(0); // C1 terminates after all forks
            }
        }

    } else {
        wait(NULL); // m waits for C1 to finish

        // Second fork: m creates C2
        pid_t pidC2 = fork();
        if (pidC2 == 0) {
            createProcess("C2");

            // Fourth fork: C2 creates C7
            pid_t pidC7 = fork();
            if (pidC7 == 0) {
                createProcess("C7");

                // Fifth fork: C7 creates 14
                pid_t pid14 = fork();
                if (pid14 == 0) {
                    createProcess("14"); // Inside 14
                } else {
                    wait(NULL); // C7 waits for 14 to finish
                    printf("Parent Process ID: %d, waiting for child 14 to finish\n", getpid());
                }

                exit(0); // C7 terminates
            } else {
                wait(NULL); // C2 waits for C7 to finish
                printf("Parent Process ID: %d, waiting for child C7 to finish\n", getpid());

                // Fifth fork: C2 creates 13
                pid_t pid13 = fork();
                if (pid13 == 0) {
                    createProcess("13"); // Inside 13
                } else {
                    wait(NULL); // C2 waits for 13 to finish
                    printf("Parent Process ID: %d, waiting for child 13 to finish\n", getpid());
                }

                exit(0); // C2 terminates after 13 and 7
            }
        } else {
            wait(NULL); // m waits for C2 to finish
            printf("Parent Process ID: %d, waiting for child C2 to finish\n", getpid());

            // Third fork: m creates C4
            pid_t pidC4 = fork();
            if (pidC4 == 0) {
                createProcess("C4");

                // Fourth fork: C4 creates C6
                pid_t pidC6 = fork();
                if (pidC6 == 0) {
                    createProcess("C6");

                    // Fifth fork: C6 creates 12
                    pid_t pid12 = fork();
                    if (pid12 == 0) {
                        createProcess("12"); // Inside 12
                    } else {
                        wait(NULL); // C6 waits for 12 to finish
                        printf("Parent Process ID: %d, waiting for child 12 to finish\n", getpid());
                    }

                    exit(0); // C6 terminates
                } else {
                    wait(NULL); // C4 waits for C6 to finish
                    printf("Parent Process ID: %d, waiting for child C6 to finish\n", getpid());

                    // Fifth fork: C4 creates 11
                    pid_t pid11 = fork();
                    if (pid11 == 0) {
                        createProcess("11"); // Inside 11
                    } else {
                        wait(NULL); // C4 waits for 11 to finish
                        printf("Parent Process ID: %d, waiting for child 11 to finish\n", getpid());
                    }

                    exit(0); // C4 terminates after 11 and 6
                }

            } else {
                wait(NULL); // m waits for C4 to finish
                printf("Parent Process ID: %d, waiting for child C4 to finish\n", getpid());

                // Fifth fork: m creates 10
                pid_t pid10 = fork();
                if (pid10 == 0) {
                    createProcess("10"); // Inside 10
                } else {
                    wait(NULL); // m waits for 10 to finish
                    printf("Parent Process ID: %d, waiting for child 10 to finish\n", getpid());
                }
            }
        }
    }


        printf("Main Process m finished, PID: %d\n", getpid());

    return 0;
}
