
#include <stdio.h>
#include <stdlib.h>

// Define op codes using an enum
typedef enum {
    LOAD = 1,   // Load value into register
    STORE,      // Store value from register into memory
    ADD,        // Add value from memory to register
    SUB,        // Subtract value from memory from register
    HALT        // Halt the program
} OpCode;

// Define the size of the memory
#define MEMORY_SIZE 10
#define REGISTER_COUNT 4

// Memory and register arrays
int memory[MEMORY_SIZE];
int registers[REGISTER_COUNT];

// Function prototypes
void fetch(int *instruction);
void decode(int instruction);
void execute(int instruction, int address);
void print_state();
void run_program(int program[], int program_size);

int main() {
    // Initialize memory with values
    memory[0] = 5;  // Initial value at address 0
    memory[1] = 10; // Initial value at address 1
    memory[3] = 3;  // Initial value at address 3

    // Sample program 1
    int program1[] = {
        LOAD, 0,
        ADD, 1,
        SUB, 3,
        STORE, 2,
        HALT
    };

    // Print initial state
    printf("Running Program 1\n");
    print_state();
    run_program(program1, sizeof(program1) / sizeof(program1[0]));
    print_state();

    // Reset registers for next program
    for (int i = 0; i < REGISTER_COUNT; i++) registers[i] = 0;


    return 0;
}

// Function to run a given program
void run_program(int program[], int program_size) {
    int instruction_pointer = 0;
    while (instruction_pointer < program_size) {
        int instruction = program[instruction_pointer++];
        int address = program[instruction_pointer++];
        fetch(&instruction);
        decode(instruction);
        execute(instruction, address);
    }
}

// Fetch the next instruction
void fetch(int *instruction) {
    printf("Fetched instruction: %d\n", *instruction);
}

// Decode the instruction
void decode(int instruction) {
    printf("Decoded instruction: %d\n", instruction);
}

// Execute the instruction
void execute(int instruction, int address) {
    switch (instruction) {
        case LOAD:
            registers[0] = memory[address];
            printf("Loaded value into register 0: %d\n", registers[0]);
            break;

        case STORE:
            memory[address] = registers[0];
            printf("Stored value from register 0 to memory address %d: %d\n", address, registers[0]);
            break;

        case ADD:
            registers[0] += memory[address];
            printf("Added value from memory address %d to register 0: %d\n", address, registers[0]);
            break;

        case SUB:
            registers[0] -= memory[address];
            printf("Subtracted value from memory address %d from register 0: %d\n", address, registers[0]);
            break;

        case HALT:
            printf("Halting the program.\n");
            exit(0);

        default:
            printf("Unknown instruction: %d\n", instruction);
            break;
    }
}

// Print the state of the computer
void print_state() {
    printf("\nCurrent State:\n");
    printf("Memory: ");
    for (int i = 0; i < MEMORY_SIZE; i++) {
        printf("%d ", memory[i]);
    }
    printf("\nRegisters: ");
    for (int i = 0; i < REGISTER_COUNT; i++) {
        printf("%d ", registers[i]);
    }
    printf("\n\n");
}
