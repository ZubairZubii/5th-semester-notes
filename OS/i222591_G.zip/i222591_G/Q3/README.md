#########################################################         Instruction Simulator README          #############################################################3

###Overview

This program simulates a simple instruction set architecture, demonstrating the fetch-decode-execute cycle. It allows for basic operations like loading, storing, adding, and subtracting values in a simulated memory environment.
Compilation Instructions

To compile the instruction_simulator.c program, follow these steps:

    Open your terminal.

    Navigate to the directory where instruction_simulator.c is located.

    Run the following command to compile the program:

    bash

    gcc -o instruction_simulator instruction_simulator.c

    If there are no errors, an executable file named instruction_simulator will be created.

##Running the Program

To run the compiled program, execute the following command in your terminal:

###bash

./instruction_simulator

###Program Output

Upon running the program, you will see the output detailing the initial state of the memory and registers, followed by the operations performed by the simulated program. Here’s an example output:

yaml

###Running Program 1

Current State:
Memory: 5 10 0 3 0 0 0 0 0 0 
Registers: 0 0 0 0 

Fetched instruction: 1
Decoded instruction: 1
Loaded value into register 0: 5
Fetched instruction: 3
Decoded instruction: 3
Added value from memory address 1 to register 0: 15
Fetched instruction: 4
Decoded instruction: 4
Subtracted value from memory address 3 from register 0: 12
Fetched instruction: 2
Decoded instruction: 2
Stored value from register 0 to memory address 2: 12
Fetched instruction: 5
Decoded instruction: 5
Halting the program.

###Explanation of Output

    Current State: Displays the contents of memory and registers before the program execution.
    Fetched instruction: Indicates the instruction currently being processed.
    Decoded instruction: Shows the numerical representation of the instruction.
    Loaded/Stored/Added/Subtracted: Describes the operation performed and its outcome.
    Halting the program: Signals the end of execution.

###Op Codes

The following op codes are defined in the program:
OpCode	Description
1	LOAD: Load value from memory to register
2	STORE: Store value from register to memory
3	ADD: Add value from memory to register
4	SUB: Subtract value from memory from register
5	HALT: Stop program execution

###Memory Layout

The program uses an array to represent memory with a fixed size defined by MEMORY_SIZE. The memory layout is initialized as follows:

    memory[0] = 5
    memory[1] = 10
    memory[3] = 3
    Other memory locations are initialized to 0.

###Sample Programs

The sample program used in this simulation is as follows:

c

int program1[] = {
    LOAD, 0,
    ADD, 1,
    SUB, 3,
    STORE, 2,
    HALT
};

###Explanation of Sample Program

    LOAD, 0: Loads the value at memory[0] (5) into register 0.
    ADD, 1: Adds the value at memory[1] (10) to register 0.
    SUB, 3: Subtracts the value at memory[3] (3) from register 0.
    STORE, 2: Stores the value of register 0 into memory[2].
    HALT: Ends program execution.
